import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'
import Demo from "../components/Demo";
import Main from "../components/main/Main";
import Home from "../components/home/Home";
import Index from "../components/home/Index";
import Login from '../components/login/Login';
import AdminList from '../components/admin/AdminList';
import AdminEdit from '../components/admin/AdminEdit';
import RuleList from '../components/rule/RuleList'
import RuleEdit from '../components/rule/RuleEdit'
import GroupList from '../components/group/GroupList'
import GroupEdit from '../components/group/GroupEdit'
import CategoryList from '../components/category/CategoryList'
import QueueList from '@/components/queue/QueueList'
import QueueDelayList from '@/components/queue/QueueDelayList'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Login',
      component: Login
    },
    {
      path: '/demo',
      name: 'Demo',
      component: Demo
    },
    {
      path:'/main',
      name:'Main',
      component:Main,
      children:[
        {
          path:'home',
          name:'Home',
          component:Home
        },
        {
          path: 'index',
          name: "Index",
          component: Index
        },
        {
          path:"admin_list",
          name:"AdminList",
          component:AdminList
        },
        {
          path:"admin_edit",
          name:"AdminEdit",
          component:AdminEdit
        },
        {
          path:"rule_list",
          name:"RuleList",
          component:RuleList
        },
        {
          path:"rule_edit",
          name:"RuleEdit",
          component:RuleEdit
        },
        {
          path:"group_list",
          name:"GroupList",
          component:GroupList
        },
        {
          path:"group_edit",
          name:"GroupEdit",
          component:GroupEdit
        },
        {
          path:"category_list",
          name:"CategoryList",
          component:CategoryList
        },
        {
          path:"queue_list",
          name:"QueueList",
          component:QueueList
        },
        {
          path:"queue_delay_list",
          name:"QueueDelayList",
          component:QueueDelayList
        },



      ]
    },
    {
      path:'/login',
      name:"Login",
      component:Login
    }
  ]
})
