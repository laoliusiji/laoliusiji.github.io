<template>
  <el-button>默认按钮</el-button>

</template>

<script>
    export default {
        name: "Demo"
    }
</script>

<style scoped>

</style>
