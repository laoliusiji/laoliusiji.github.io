<template>
  <div>
    <el-card>
      <div slot="header">
        <span>角色列表</span>
      </div>

      <div class="col">

        <el-button type="success" @click='edit("")' size="small" style="width: 80px;">新增</el-button>

        <el-table :data="list.data" style="width: 100%" v-loading='loading' stripe>
          <el-table-column prop="id" label="ID">
          </el-table-column>


          <el-table-column prop="title" label="角色名称">
          </el-table-column>



          <el-table-column label="操作">

            <template slot-scope="scope">
              <el-button type="primary" size="mini" @click='edit(scope.row)'>编辑</el-button>
              <el-button type="danger" size="mini" @click='destroy(scope.row.id)'>删除</el-button>
            </template>

          </el-table-column>

        </el-table>

        <el-divider></el-divider>

        <el-pagination layout="prev,pager,next" :current-page='this.$route.query.p | page' :total="list.total"
          @current-change='next' background>
        </el-pagination>

      </div>



    </el-card>
  </div>
</template>

<script>
  export default {
    name: "GroupList",
    data() {
      return {
        loading: false,
        list: {},

      }
    },
    methods: {

      next(page) {

        this.routerSearch(this,{p:page});

      },
      edit(row) {
        
        this.$router.push({
          path:"/main/group_edit",
          query:{id:row.id}
        });

      },
      destroy(id) {
        
        this.msgBoxAjax('警告','确定删除吗？','/admin/rule_group/group_delete/id/'+id).then((re)=>{
          
          if(re.code==1) return this.$emit('reload');
          
          return this.$message(re.msg);
          
        });

      },
      getGroupList(){

        this.loading=true;

        this.httpPost({
          url:"/admin/rule_group/group_list",
          data:this.$route.query
        }).then((re)=>{

          // console.log(re);

          this.loading=false;

          this.list=re.data;


        });

      }



    },
    created() {

      this.getGroupList();

    },
    computed: {

    }

  }
</script>

<style>
</style>
