<template>
  <div>
    <el-card>
      <div slot="header">
        <span>角色编辑</span>
      </div>

      <div class="col">

        <div class="col">
          <span style="margin-bottom: 10px;">角色名称</span>
          <el-input size="small" style="width: 20%;" v-model="title"></el-input>
        </div>

        <el-divider></el-divider>

        <div>


          <div class="col" v-for="(v,i) in rule_list" :key='i' style="margin-bottom: 20px;">


            <label style="font-weight: bold;margin-bottom: 10px;">{{i}}</label>

            <el-checkbox-group v-model="checkList" class="group">

              <el-checkbox :label="v1.id" v-for="(v1,i1) in v" :key='i+i1'>{{v1.title}}</el-checkbox>


            </el-checkbox-group>

          </div>

        </div>

        <div>
          <el-button type="primary" @click='sumit()'>提交</el-button>
        </div>


      </div>


    </el-card>
  </div>
</template>

<script>
  export default {
    name: "GroupEdit",
    data() {
      return {
        checkList: [],
        rule_list:[],
        title:""

      }
    },
    methods: {

      getAllRule(){

        this.httpPost({
          url:'/admin/rule_group/all_rules'
        }).then((re)=>{

          this.rule_list=re.data;
        });

      },
      updateRule(){

        let data={title:this.title,rules:this.checkList};

        let id=this.$route.query.id;

        if(id) data.id=id;

        this.httpPost({
          url:"/admin/rule_group/rule_update",
          data:data
        }).then((re)=>{

          // console.log(re);

          this.messageSuccess('提示','修改成功,返回列表页面吗？').then(()=>{
            this.$router.go(-1);
          });

        });

      },
      sumit(){

        this.messageCommon('提示','确定提交吗?','info').then(()=>{

          this.updateRule();

        }).catch(()=>{});
      },
      getRuleInfo(id){

        this.httpPost({
          url:"/admin/rule_group/get_rule_info/id/"+id
        }).then((re)=>{


          this.title=re.data.title;

          this.checkList=re.data.rules;
        });

      }

    },
    created() {
      this.getAllRule();

      let id=this.$route.query.id;

      if(id) this.getRuleInfo(id);

    },
    computed: {

    }

  }
</script>

<style>
  .group {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
  }

  .group>label {

    margin-bottom: 15px;
    width: 15%;
  }
</style>
