<template>
  <div>
    <el-card>
      <div slot="header">
        <span>规则编辑</span>
      </div>

      <div class="row center-row">
        <div style="width: 40%;">
          <el-form label-position="right" label-width="80px" :model="item" ref='form' :rules="rules">
            <el-form-item label="描述" prop="title">
              <el-input v-model="item.title" size="small" placeholder="描述"></el-input>
            </el-form-item>

            <el-form-item label="路由规则" prop="rule">
              <el-autocomplete :fetch-suggestions="getTip" :trigger-on-focus="false" v-model="item.rule" size='small'
                style="width: 100%;" placeholder="路由规则">
              </el-autocomplete>
            </el-form-item>

            <el-form-item label="分组名称">
              <el-input v-model="item.group_name" size="small" placeholder="分组名称"></el-input>
            </el-form-item>


            <el-form-item>
              <el-button type="primary" size="small" @click='submit()'>提交</el-button>
            </el-form-item>

          </el-form>
        </div>
      </div>


    </el-card>
  </div>
</template>

<script>
  export default {
    name: "RuleEdit",
    data() {
      return {
        item: {
          rule: '',
          title: "",
          group_name: ""
        },
        rules: {
          title: [{
            required: true,
            message: '描述不能为空',
            trigger: 'blur'
          }],
          rule: [{
            required: true,
            message: '路由不能为空',
            trigger: 'blur'
          }],

        },

      }
    },
    methods: {

      submit() {


        this.$refs['form'].validate((valid) => {
          if (valid) {

            this.updateRule();

          } else {
            console.log('error submit!!');
            return false;
          }
        });


      },
      getInfo(id) {

        const loading = this.$loading({
          lock: true,
          text: 'Loading',
          spinner: 'el-icon-loading',
          background: 'rgba(0, 0, 0, 0.7)'
        });

        this.httpPost({
          url: "/admin/rule/rule_info/id/" + id
        }).then((re) => {

          this.setItem(this.item, re.data);

          this.$nextTick(() => {

            loading.close();

          });

        }).catch((re) => {

          loading.close();
          this.messageCommon('错误', re.msg, 'error').then(() => {

            this.$router.go(-1);
          });

        });

      },
      updateRule() {

        let temp = this.cloneObj(this.item);

        let id = this.$route.query.id;

        if (id) temp.id = id;

        this.httpPost({
          url: "/admin/rule/rule_update",
          data: temp
        }).then((re) => {

          // console.log(re);

          this.messageSuccess('提示', '更新成功，返回上一层吗？').then(() => {

            this.$router.go(-1);
          });


        });


      },
      getTip(queryString, cb) {

        console.log(queryString);


        //         setTimeout(()=>{
        //
        //           cb([]);
        //
        //         },1000);


        this.getRoute(queryString).then((re)=>{

          cb(re.data);

        });


      },
      getRoute(keyword) {


        return new Promise((success, fail) => {

          this.httpPost({
            url: "/admin/route/getRouteTip",
            data:{keyword:keyword}
          }).then((re) => {



            success(re);

          }).catch((re)=>{

            fail(re);
          });

        });


      }



    },
    created() {

      let id = this.$route.query.id;

      if (id) this.getInfo(id);

    },
    computed: {

    }

  }
</script>

<style>
</style>
