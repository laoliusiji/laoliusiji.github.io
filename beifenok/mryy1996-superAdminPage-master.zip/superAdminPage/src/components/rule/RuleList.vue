<template>
  <div>
    <div>
      <el-card>
        <div slot="header">
          <span>路由列表</span>
        </div>

        <div class="col">

          <el-button type="success" @click='edit("")' size="small" style="width: 80px;">新增</el-button>

          <el-table :data="list.data" style="width: 100%" v-loading='loading' stripe>
            <el-table-column prop="id" label="ID">
            </el-table-column>
            <el-table-column prop="title" label="描述">
            </el-table-column>
            <el-table-column prop="rule" label="路由规则">
            </el-table-column>
            <el-table-column prop="created_at" label="创建时间">
            </el-table-column>

            <el-table-column prop="updated_at" label="修改时间">
            </el-table-column>



            <el-table-column label="操作">

              <template slot-scope="scope">
                <el-button type="primary" size="mini" @click='edit(scope.row)'>编辑</el-button>
                <el-button type="danger" size="mini" @click='destroy(scope.row.id)'>删除</el-button>
              </template>

            </el-table-column>

          </el-table>

          <el-divider></el-divider>

          <el-pagination layout="prev,pager,next" :current-page='this.$route.query.p | page' :total="list.total"
            @current-change='next' background>
          </el-pagination>

        </div>


      </el-card>
    </div>
  </div>
</template>

<script>
  export default {
    name: "RuleList",
    data() {
      return {
        list: {},
        loading: false
      }
    },
    methods: {
      next(page) {
        
        this.routerSearch(this,{p:page});
      },
      getRuleList() {

        this.loading=true;
        this.httpPost({
          url: "/admin/rule/rule_list",
          data: this.$route.query
        }).then((re) => {

          // console.log(re);


          this.list=re.data;

          this.$nextTick(()=>{

            this.loading=false;
          });


        });

      },
      edit(row){

        this.$router.push({
          path:"/main/rule_edit",
          query:{id:row.id}
        });

      },
      destroy(id){
        let that=this;
        this.msgBoxAjax('警告','确定删除吗？','/admin/rule/rule_delete/id/'+id).then((re)=>{

          if(re.code==1) this.$emit('reload');
        });

      }

    },
    created() {

      this.getRuleList();
    },
    computed: {

    }

  }
</script>

<style>
</style>
