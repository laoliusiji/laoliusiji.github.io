<template>
  <div>
    <el-card>
      <div slot="header">
        <span>正在运行的任务</span>
      </div>

      <div class="col">


        <el-table :data="list.data" style="width: 100%" v-loading='loading' stripe>
          <el-table-column label="序号">
            <template slot-scope='scope'>

              <span>{{scope.$index+1}}</span>
            </template>

          </el-table-column>


          <el-table-column label="任务类名">
            <template slot-scope='scope'>

              <span>{{scope.row.displayName}}</span>
            </template>

          </el-table-column>

          <el-table-column label="执行时间">
            <template slot-scope='scope'>

              <span>{{scope.row.runTime}}</span>
            </template>

          </el-table-column>


          <el-table-column label="参数">
            <template slot-scope='scope'>

              <el-button type="primary" size="small" @click='showParams(scope.row)'>查看</el-button>

            </template>

          </el-table-column>



        </el-table>

        <el-divider></el-divider>

        <el-pagination layout="prev,pager,next" :current-page='this.$route.query.p | page' :total="list.total"
          @current-change='next' background>
        </el-pagination>

      </div>


      <el-dialog title="提示" :visible.sync="dialogVisible" width="30%" >

        <p v-for="(v,i) in params" :key='i'>{{i}}:{{v}}</p>
        <span slot="footer" class="dialog-footer">
          <el-button @click="dialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
        </span>
      </el-dialog>


    </el-card>
  </div>
</template>

<script>
  export default {
    name: "QueueList",
    data() {
      return {
        loading: false,
        list: {},
        dialogVisible: false,
        params:{}

      }
    },
    methods: {

      next(page) {

        this.routerSearch(this, {
          p: page
        });

      },
      edit(row) {

      },
      destroy(id) {

      },
      getList() {
        this.loading=true;
        this.httpPost({
          url: "/admin/queue/getDelayTask",
          data: this.$route.query
        }).then((re) => {

          this.loading=false;
          this.list = re.data;

        });

      },
      showParams(obj) {

        this.dialogVisible = true;

        this.params=obj.params;

      }




    },
    created() {

      this.getList();
    },
    computed: {

    }

  }
</script>

<style>
</style>
