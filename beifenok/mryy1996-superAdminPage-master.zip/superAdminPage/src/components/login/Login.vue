<template>
  <div style="height: 100vh;width: 100vw;background-color: #EEEEEE;background-image: url(../../../static/img/backgroud.jpeg);background-repeat: no-repeat;background-size: 100% 100%;"
    class="row center-col center-row">
    <el-form>
      <div class="col m" style="margin-bottom: 200px;">
        <div style="font-size: 2em;text-align: center;">Super Admin</div>
        <div style="color: #999999;text-align: center;">高效后台框架</div>

        <div style="width: 400px;">
          <el-input clearable v-model="username" prefix-icon="el-icon-user-solid"></el-input>
        </div>

        <div style="width: 400px;">
          <el-input clearable v-model="password" type="password" prefix-icon="el-icon-lock"></el-input>
        </div>

        <div class="row-no-full" style="justify-content: space-between;">
          <el-checkbox v-model="checked">记住密码</el-checkbox>
          <el-link type="primary">忘记密码?</el-link>

        </div>

        <el-button type="primary" @click='submit'>登录</el-button>


      </div>
    </el-form>
  </div>
</template>

<script>
  export default {
    name: "Login",
    data() {
      return {
        username: "",
        password: "",
        checked: false
      }
    },
    methods: {

      submit() {

        // console.log(process.env);

        this.httpPost({
          url: '/admin/login/login',
          data: {
            username: this.username,
            password: this.password
          }
        }).then((res) => {

          // console.log(res);

          if (res.code == 1) {

            this.localSet('token', res.data);

            this.$router.push('/main/home');

          }else{
            
            this.$message.error('密码错误！');
          }


        });


      }

    }
  }
</script>

<style>
  .m>* {
    margin-bottom: 20px;
  }
</style>
