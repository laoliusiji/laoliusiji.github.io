<template>
<h1>Index</h1>
</template>

<script>
    export default {
        name: "Index"
    }
</script>

<style scoped>

</style>
