<template>
    <div style="width: 100%;min-height: 90vh;" class="row-no-full center-col center-row">
        <h1>主页</h1>
    </div>
</template>

<script>
    export default {
        name: "Home",
        created() {
          
          this.getHome();
        },
        methods:{
          getHome(){
            this.httpPost({
              url:"/admin/home/home"
            }).then((re)=>{
              console.log(re);
            });
          }
        }
    }
</script>

<style scoped>

</style>
