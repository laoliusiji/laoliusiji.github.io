<template>
  <div>
    <div>
      <el-card>

        <div slot="header">
          <span>管理员列表</span>
        </div>

        <div class="col">

          <el-button type="success" @click='edit("")' size="small" style="width: 80px;">新增</el-button>

          <el-table :data="list.data" style="width: 100%" v-loading='loading' stripe>
            <el-table-column prop="id" label="ID">
            </el-table-column>
            <el-table-column prop="username" label="用户名">
            </el-table-column>
            <el-table-column prop="nick_name" label="昵称">
            </el-table-column>
            <el-table-column prop="created_at" label="创建时间">
            </el-table-column>

            <el-table-column label="上次登录时间">
              <template slot-scope="scope">
                <span v-if="scope.row.last_login_time">{{scope.row.last_login_time}}</span>
              </template>
            </el-table-column>

            <el-table-column label="操作">

              <template slot-scope="scope">
                <el-button type="primary" size="mini" @click='edit(scope.row)'>编辑</el-button>
                <el-button type="danger" size="mini" @click='deleteAdmin(scope.row.id)'>删除</el-button>
              </template>

            </el-table-column>

          </el-table>

          <el-divider></el-divider>

          <el-pagination layout="prev,pager,next" :current-page='this.$route.query.p | page' :total="list.total"
            @current-change='next' background>
          </el-pagination>

        </div>


      </el-card>
    </div>
  </div>
</template>

<script>
  export default {
    name: "AdminList",
    data() {
      return {

        list: [],
        loading: false,
        search: {}


      }
    },
    inject: ['reload'],
    methods: {

      getAdminList() {

        this.loading = true;
        this.httpPost({
          url: "/admin/admin/admin_list",
          data: this.$route.query

        }).then((re) => {


          this.list = re.data;

          this.loading = false;
        });
      },
      next(page) {


        this.routerSearch(this,{p:page});


      },
      edit(obj) {

        this.$router.push({
          path: '/main/admin_edit',
          query: {
            id: obj.id
          }
        });
      },
      deleteAdmin(id) {

        this.messageCommon('警告', '确定删除吗？', 'warning').then(() => {

          this.httpPost({
            url: "/admin/admin/admin_delete/id/" + id,

          }).then((re) => {

            // console.log(re);

            if (re.code == 1) {

              this.getAdminList();
            }else{

              this.$message.error(re.msg);
            }

          });

        });

      }

    },
    created() {

      this.getAdminList();


    },
    computed: {

    }

  }
</script>

<style>
</style>
