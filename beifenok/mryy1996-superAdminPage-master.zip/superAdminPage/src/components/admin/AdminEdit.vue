<template>
  <div>
    <el-card>
      <div slot="header">
        <span>管理员编辑</span>
      </div>

      <div class="row center-row">
        <div style="width: 40%;">
          <el-form label-position="right" label-width="80px" :model="item" ref='form' :rules="rules">
            <el-form-item label="用户名" prop="username">
              <el-input v-model="item.username" size="small" placeholder="用户名"></el-input>
            </el-form-item>

            <el-form-item label="邮箱" prop="email">
              <el-input v-model="item.email" size="small" placeholder="邮箱"></el-input>
            </el-form-item>

            <el-form-item label="角色" prop="group_id">
              <!-- <el-input v-model="item.group_id" size="small" placeholder="角色"></el-input> -->
              <el-select v-model="item.group_id" placeholder="请选择" size="small" style="width: 100%;">
                <el-option :key='0' label="超级管理员" :value="0"></el-option>
                <el-option v-for="item in groupList" :key="item.id" :label="item.title" :value="item.id">
                </el-option>
              </el-select>


            </el-form-item>

            <el-form-item label="密码" prop="password">
              <el-input v-model="item.password" type="password" size="small" placeholder="密码"></el-input>
            </el-form-item>

            <el-form-item label="确认密码" prop="re_password">
              <el-input v-model="item.re_password" type="password" size="small" placeholder="确认密码"></el-input>
            </el-form-item>

            <el-form-item>
              <el-button type="primary" size="small" @click='submit()'>提交</el-button>
            </el-form-item>

          </el-form>
        </div>
      </div>

    </el-card>

  </div>
</template>

<script>
  export default {
    name: "AdminEdit",
    data() {
      return {

        item: {
          username: '',
          email: "",
          password: '',
          re_password: '',
          group_id: null
        },
        rules: {
          username: [{
            required: true,
            message: '用户名不能为空',
            trigger: 'blur'
          }],
          email: [{
              required: true,
              message: '邮箱不能为空',
              trigger: 'blur'
            },
            {
              type: 'email',
              message: '邮箱格式不正确',
              trigger: ['blur', 'change']
            }
          ],
          password: [{
            required: true,
            message: '密码不能为空',
            trigger: 'blur'
          }],
          re_password: [{
            required: true,
            message: '密码不能为空',
            trigger: 'blur'
          }]

        },
        groupList: []

      }
    },
    methods: {
      submit() {


        this.$refs['form'].validate((valid) => {
          if (valid) {

            if (this.item.password != this.item.re_password) return this.$message.error('两次密码不一致！');

            this.updateAdmin();


          } else {
            console.log('error submit!!');
            return false;
          }
        });


      },
      updateAdmin() {


        let temp = this.cloneObj(this.item);

        delete temp.re_password;

        let id = this.$route.query.id;

        console.log(id);

        if (!id) id = '';


        this.msgBoxAjax(
          '提示',
          '确定修改吗？',
          "/admin/admin/admin_update?id=" + id,
          temp).then((data) => {
          // console.log(data);

          if (data.code == 1) {
            this.messageSuccess('提示', '操作成功，需要返回列表页面吗？').then(() => {

              this.$router.go(-1);
            });
          }else{

            this.messageCommon('错误',data.msg,'error');
          }


        });

      },
      getAdminInfo(id) {

        let load = this.$loading({
          lock: true,
          text: 'Loading',
          spinner: 'el-icon-loading',
          background: 'rgba(0, 0, 0, 0.7)'
        });

        this.httpPost({
          url: "/admin/admin/admin_info",
          data: {
            id: id
          }
        }).then((re) => {

          load.close();

          this.setItem(this.item, re.data);
        }).catch((re)=>{

          load.close();

          this.messageCommon('错误',re.msg,'error').then(()=>{
            this.$router.go(-1)
          });


        });
      },
      getAllGroupName() {

        this.httpPost({
          url: "/admin/admin/getAllGroupName"
        }).then((re) => {
          // console.log(re);

          this.groupList = re.data;
        });

      }

    },
    created() {


      let id = this.$route.query.id;

      if (id) {

        this.getAdminInfo(id);

        this.rules.password = [];
        this.rules.re_password = [];

      }

      this.getAllGroupName();



    },
    computed: {

    }

  }
</script>

<style>
  .item {
    display: flex;
    width: 40%;
    align-items: center;
  }



  .title {
    display: flex;
    align-items: center;

  }

  .title>p {
    white-space: nowrap;
    margin-right: 8px;
    color: #606266;
    font-size: 14px;

  }

  .title>span {
    color: red;
    font-size: 12px;
    margin-right: 4px;
  }
</style>
