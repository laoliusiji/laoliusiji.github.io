<template>

  <div class="row-no-full">
    <!-- 菜单栏 -->
    <div class="col" style="height: 100vh;width: 18vw;background-color: #191a23;box-shadow: 2px 0 6px rgba(0,21,41,.35);position: fixed;">
      <div class="row center-row">
        <h1 style="color: azure">Super Admin</h1>
      </div>
      <div class="aline_"></div>

      <div>

        <el-menu :default-active="checkedIndex" class="el-menu-vertical-demo" @open="handleOpen" @close="handleClose"
          :collapse="isCollapse" background-color="#191a23" text-color="#fff" active-text-color="#ffd04b" style="width: 100%">

          <el-submenu v-for="(v,i) in menu" :index="i+''" :key="i">


            <template slot="title">
              <i class="el-icon-location"></i>
              <span slot="title">{{v.name}}</span>
            </template>

            <el-menu-item @click="toContent(v1)" :key="i+'-'+i1" v-for="(v1,i1) in v.children" :index="v1.path">
              {{v1.name}}
            </el-menu-item>


          </el-submenu>


        </el-menu>

      </div>

    </div>

    <div style="width: 18vw;"></div>
    <div class="col" style="flex: 1">

      <!-- 头部 -->
      <div class="row-no-full" style="height: 80px;box-shadow: 0 1px 4px rgba(0,21,41,.08);position: fixed;width: 82vw;z-index: 1000;background-color:#fff">
        <div class="row-no-full center-col" style="padding: 0 20px;justify-content: space-between;width: 100%;">
          <!-- 面包屑 -->
          <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item>{{current[0]}}</el-breadcrumb-item>
            <el-breadcrumb-item>{{current[1]}}</el-breadcrumb-item>

          </el-breadcrumb>


          <div class="row-no-full center-col">
            <el-badge value="10">
              <i class="el-icon-bell" style="font-size: 25px;"></i>
            </el-badge>
            <!-- 占位 -->
            <div style="width: 35px;"></div>




            <!-- 头像 -->
            <el-dropdown>
              <div class="row-no-full center-col hover" style="height: 80px;padding: 0 15px;">
                <el-avatar src="../../../static/img/head.jpeg"></el-avatar>
                <div style="color: #515a6e;margin-left: 10px;">peter</div>
              </div>

              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item>个人中心</el-dropdown-item>

                <el-dropdown-item @click.native='logout()' divided>退出登录</el-dropdown-item>

              </el-dropdown-menu>

            </el-dropdown>


          </div>

        </div>
      </div>
      <!-- 占位 -->
      <div style="height: 80px;"></div>
      <!-- 内容 -->
      <div>
        <router-view v-if='isRouterAlive' @reload='reloads()'  style="padding: 25px;" />
      </div>

    </div>

  </div>
</template>

<script>
  export default {
    name: "Main",
    provide() {
      return {
        reload: this.reload
      }
    },
    methods: {
      handleOpen(key, keyPath) {
        console.log(key, keyPath);
      },
      handleClose(key, keyPath) {
        console.log(key, keyPath);
      },
      toContent(obj) {

        console.log(obj);

        this.$router.push(obj.path);

        this.current = obj.title;


      },
      logout() {



        this.localRemove('token');

        this.$router.push('/login');

      },
      reload() {
        this.isRouterAlive = false;

        this.$nextTick(() => {

          this.isRouterAlive = true;
        });

      },
      reloads(){
        this.isRouterAlive = false;

        this.$nextTick(() => {

          this.isRouterAlive = true;
        });
      },
      getMenu(){

        this.httpPost({
          url:"/admin/menu/getMenu"
        }).then((re)=>{
          // console.log(re);

          this.menu=re.data;
        });

      }

    },
    data() {
      return {

        isCollapse: false,
        menu: [],
        current: ['用户管理', '用户列表'],

        checkedIndex: '',
        isRouterAlive: true

      };

    },
    created() {


      // console.log(this.$route.path);

      this.getMenu();

      //地址栏选中
      let path = this.$router.history.current.path;

      this.checkedIndex = path;

      console.log(this.getEnv('host'));

    }
  }
</script>

<style scoped>
  .aline_ {
    border-bottom: 1px solid #101117;
  }

  .hover:hover {
    background-color: #E6E3E3
  }
</style>
