<template>
  <div>
    <el-card>
      <div slot="header">
        <span>分类列表</span>
      </div>

      <div class="col">

        <el-button type="success" @click='edit("")' size="small" style="width: 80px;">新增</el-button>

        <el-table :data="listShow" style="width: 100%" v-loading='loading' stripe>
          <el-table-column prop="id" label="ID">
          </el-table-column>

          <el-table-column label="名称">

            <template slot-scope='scope'>


              <span v-for="v in scope.row.lv-1" :key='v.id'>&#12288;&#12288;</span>


              <span>

                <span class="p" v-if="!isOver(scope.row.id)">
                  <span v-if='scope.row.status=="hidden"' class="el-icon-caret-right" @click="show(scope.row)"></span>

                  <span v-else class="el-icon-caret-bottom" @click="hidden(scope.row,scope.$index)"></span>
                </span>
                <!-- 透明占位 -->
                <span v-else class="el-icon-caret-bottom" style="opacity: 0;"></span>

                {{scope.row.name}}
              </span>


            </template>

          </el-table-column>

          <el-table-column label="操作">

            <template slot-scope="scope">
              <el-button type="success" size="mini" @click='addSon(scope.row)'>添加子分类</el-button>
              <el-button type="primary" size="mini" @click='edit(scope.row)'>编辑</el-button>
              <el-button type="danger" size="mini" @click='destroy(scope.row.id)'>删除</el-button>
            </template>

          </el-table-column>

        </el-table>



      </div>



    </el-card>

    <el-dialog title="分类编辑" :visible.sync="dialogFormVisible">

      <div class="col">
        <div class="row-no-full center-col item-right">
          <span style="white-space: nowrap;">分类名称</span>
          <el-input v-model="item.name"></el-input>
        </div>

        <div class="row-no-full  item-right">
          <span style="white-space: nowrap;">分类图片</span>
          <div class="col">

            <div class="upload" style="margin-bottom: 20px;">
              <input type="file" @change="uploadImg($event)" />
              <el-button type="success" size="small">上传图片</el-button>
            </div>

            <el-image v-if='item.img' style='max-width: 400px;' :src='getImgPrefix()+item.img' fit='contain'></el-image>

          </div>
        </div>

      </div>

      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="submit()">确 定</el-button>
      </div>
    </el-dialog>


  </div>
</template>

<script>
  export default {
    name: "GroupList",
    data() {
      return {
        loading: false,
        list: [],
        dialogFormVisible: false,
        item: {
          name: "",
          img: "",
          pid: 0,
          lv:1

        },



      }
    },
    methods: {

      edit(row) {

        let temp = this.cloneObj(row);

        if (row) {

          this.item = temp;

        } else {

          this.resetObj(this.item);
        }

        this.dialogFormVisible = true;

      },
      addSon(row){

        let temp=this.cloneObj(row)

        this.resetObj(this.item);

        this.item.pid=temp.id;

        this.item.lv=++temp.lv;

        this.dialogFormVisible=true;

        // this.cate

      },

      destroy(id) {

        this.msgBoxAjax('警告','确定删除吗？','/admin/category/categoryDelete',{id:id})
        .then((re)=>{

          // console.log(re);

          if(re.code!=1) return this.$message.error(re.msg);

          this.getCategoryList();

        }

        );

      },
      getCategoryList() {

        this.loading = true;
        this.httpPost({
          url: "/admin/category/categoryList"

        }).then((re) => {

          // console.log(re);

          this.list = re.data;

          this.$nextTick(() => {

            this.loading = false;
          });

        }).catch(() => {

          this.loading = false;
        });

      },
      hidden(row, index) {



        let id = row.id;

        for (let i in this.list) {

          let pid = this.list[i].pid;

          let obj = this.list[i];

          if (pid == id) {

            obj.show = false;

            this.list.splice(i, 1, obj);

            this.hidden(obj);

          }



        }



        row.status = 'hidden';



      },
      show(row) {


        let id = row.id;

        for (let i in this.list) {

          let pid = this.list[i].pid;

          let obj = this.list[i];

          if (pid == id) {

            obj.show = true;

            this.list.splice(i, 1, obj);


          }



        }



        row.status = 'show';

      },
      isOver(id) {

        // let ok=false;

        for (let i in this.list) {

          let pid = this.list[i].pid;

          if (id == pid) return false;

        }

        return true;
      },
      uploadImg(event) {

        console.log(event.target.files[0]);

        let file = event.target.files[0];

        let form = new FormData();

        form.append('file', file);

        this.httpPost({
          url: "/admin/upload/upload",
          data: form
        }).then((re) => {

          console.log(re);

          this.item.img = re.data;



        });




      },
      submit() {

        this.httpPost({
          url: "/admin/category/categoryUpdate",
          data: this.item
        }).then((re) => {

          console.log(re);

          this.dialogFormVisible=false;

          this.getCategoryList();

        });

      },
      categoryDelete(){


      }



    },
    created() {

      this.getCategoryList();
    },
    computed: {
      listShow() {

        let tem = [];

        for (let i in this.list) {

          if (this.list[i].show !== false) {

            let obj = this.list[i];

            // obj.status='show'

            tem.push(obj);
          }

          // if(this.list[i].status=)

        }

        return tem;
      }
    }

  }
</script>

<style>
  .p:hover {

    cursor: pointer;
  }

  .item-right {

    margin-bottom: 30px;
  }

  .item-right>span {

    margin-right: 20px;
  }
</style>
