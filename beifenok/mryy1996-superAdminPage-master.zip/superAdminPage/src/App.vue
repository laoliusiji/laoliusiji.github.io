<template>
  <div id="app">
    <router-view/>
  </div>

</template>



<script>
    export default {
        name: 'App',
        created() {
          console.log(this.$router);
        }
    }
</script>

<style>
  /*#app {*/
  /*  font-family: 'Avenir', Helvetica, Arial, sans-serif;*/
  /*  -webkit-font-smoothing: antialiased;*/
  /*  -moz-osx-font-smoothing: grayscale;*/
  /*  text-align: center;*/
  /*  color: #2c3e50;*/
  /*  margin-top: 60px;*/
  /*}*/

  body{
    margin: 0;
  }

  .col {
    display: flex;
    flex-direction: column;
  }

  .row {

    display: flex;
    width: 100%;

  }

  .row-no-full {

    display: flex;

  }

  .nowrap {
    white-space: nowrap;
  }

  .center-row {

    justify-content: center;
  }

  .center-col {

    align-items: center;
  }

  .wrap {

    white-space: pre-wrap;

    line-height: 100%;
  }


  .all {
    width: 100%;
  }


  /*.bottom_line {*/
  /*  !* border-bottom: 1upx solid #C0C0C0; *!*/
  /*  padding-bottom: 8 upx;*/
  /*  !* margin-left: 20upx; *!*/
  /*  display: inline-block;*/
  /*  width: 100%;*/

  /*  text-decoration: underline;*/
  /*}*/

  .aline {
    background-color: #E6E3E3;
    height: 1px;
  }


  .bold {

    font-weight: bold;
  }

  .c666 {
    color: #666;
  }

  .blue {

    color: #009EE2;
  }

  .shadow {


    box-shadow: 0px 0px 8px #ccc;
  }

  .border-radius {

    border-radius: 0.1166rem;
  }

  .upload{
    position: relative;
    width: -webkit-fit-content;

  }
  .upload>input{
    width: 100%;
    height: 100%;
    opacity: 0;
    position: absolute;

  }

</style>
