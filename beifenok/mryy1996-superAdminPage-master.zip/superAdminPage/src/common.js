import Vue from 'vue'
import axios from 'axios'
import router from './router'
import env from './env.js'




//公共函数
//-----------------------------------------------------------------------------------------------
/**
 * 判断运行环境
 */
Vue.prototype.isDev = function() {

  if (process.env.NODE_ENV == 'development') return true;

  return false;

}

/**
 * 获取api域名
 */
Vue.prototype.getHost = function() {

  return process.env.HOST;

  // if (Vue.prototype.isDev()) return 'http://lv.com/api';

}

/**
 * 公共请求方法
 * @param {Object} params
 */
Vue.prototype.httpCommon = function(params) {

  params.baseURL = Vue.prototype.getEnv('host')

  params.headers = {
    'token': Vue.prototype.localGet('token'),
    // 'rule':Vue.$route.path
  };

  return new Promise((resolve, reject) => {

    axios(params).then((res) => {

      if (res.data.code >= 10 && res.data.code <= 50){

        reject(res.data);

        return router.push('/login');
      }

      if(res.data.code>=51&&res.data.code<=100){

        reject(res.data);

        return false;
        // return this.$message.error(res.data.msg);
      }


      resolve(res.data);


    });

  });

}

/**
 * get请求，数据用params
 * @param {Object} params
 */
Vue.prototype.httpGet = function(params) {


  params.method = 'get';

  return new Promise((resolve, reject) => {
    Vue.prototype.httpCommon(params).then((res) => {

      resolve(res);

    }).catch((res)=>{
      reject(res);
    });

  });

}

/**
 * post请求，数据用data
 * @param {Object} params
 */
Vue.prototype.httpPost = function(params) {


  params.method = 'post';

  return new Promise((resolve, reject) => {
    Vue.prototype.httpCommon(params).then((res) => {

      resolve(res);

    }).catch((res)=>{

      reject(res);
    });

  });


}


/**
 * 本地储存
 */
Vue.prototype.localSet = function(key, value, prefix = 'super_admin_') {

  localStorage.setItem(prefix + key, value);

}


/**
 * 本地储存获取
 */
Vue.prototype.localGet = function(key, defaultValue = '', prefix = 'super_admin_') {

  let re = localStorage.getItem(prefix + key);

  if (!re) return defaultValue;

  return re;

}

/**
 * 删除
 */
Vue.prototype.localRemove = function(key, prefix = 'super_admin_') {

  localStorage.removeItem(prefix + key);

}


/**
 * 克隆对象
 * @param {Object} object
 */
Vue.prototype.cloneObj = function(object) {

  return JSON.parse(JSON.stringify(object))
}


/**
 * item赋值
 * @param {Object} defaultItem
 * @param {Object} item
 */
Vue.prototype.setItem = function(defaultItem, item) {

  // console.log(item);
  for (let key in defaultItem) {

    // console.log(item[key]);

    console.log(typeof(item[key]));
    if (!(typeof(item[key]) == 'undefined')) {

      // console.log(item[key]);
      defaultItem[key] = item[key];
    }

  }
}

Vue.prototype.messageCommon = function(title, message, type) {

  return new Promise((success, fail) => {

    this.$confirm(message, title, {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: type
    }).then(() => {

      success();
    }).catch(() => {
      // console.log('fail');
      fail();
    });

  });

}


Vue.prototype.messageSuccess = function(title, message) {


  return new Promise((success, fail) => {

    Vue.prototype.messageCommon(title, message, 'success').then(() => {

      success();

    }).catch(() => {

      fail();

    });

  });


}


/**
 * 搜索跳转
 *
 * @param context  上下文对象（this）
 * @param query    参数
 * @param rememberQuery 是否保存其他参数
 */
Vue.prototype.routerSearch = function(context, query, rememberQuery = true) {

  let path = context.$route.path;

  let temp = context.$route.query;

  let oldQuery = context.cloneObj(temp);


  for (let key in query) {

    let item = query[key];

    oldQuery[key] = item;

  }

  let searchQuery = oldQuery;

  if (!rememberQuery) searchQuery = query;

  context.$router.push({
    path: path,
    query: searchQuery
  });

  context.$emit('reload');

}

/**
 * 弹窗+ajax请求
 *
 * @param title 弹窗标题
 * @param message 弹窗内容
 * @param url 请求地址
 * @param data 请求数据
 *
 */
Vue.prototype.msgBoxAjax = function(title, message, url, data = {}) {

  return new Promise((success, fail) => {

    let i = this.$msgbox({
      title: title,
      message: message,
      showCancelButton: true,
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      // distinguishCancelAndClose:true
      closeOnClickModal: false,
      closeOnPressEscape: false,
      // closeOnHashChange: false,
      beforeClose: (action, instance, done) => {
        if (action === 'confirm') {

          console.log(instance);
          instance.confirmButtonLoading = true;
          instance.confirmButtonText = '执行中...';

          this.httpPost({
            url: url,
            data: data
          }).then((re) => {
            // console.log(re);
            done();

            instance.confirmButtonLoading = false;



            i.responseData = re;



          }).catch(()=>{
            instance.confirmButtonLoading = false;
            done();
          });


        } else {
          done();
        }
      }
    }).then((action, instance, done) => {

      if (action == 'confirm') {

        success(i.responseData);
      } else {


      }

    }).catch(() => {


      fail();

    });


  });


}


Vue.prototype.getEnv=function(key){

  return env[key];
}

/**
 * 获取图片域名
 */
Vue.prototype.getImgPrefix=function(){

  return Vue.prototype.getEnv('host')+'/uploads/';
}

/**
 * 重置对象
 * @param {Object} obj
 */
Vue.prototype.resetObj=function(obj){

  for(let i in obj){

    switch(typeof obj[i]){

      case 'number':

        obj[i]=0;

      break;

      case 'string':

        obj[i]='';

      break;

      case 'object':


        // obj[i]=[];

        if(obj[i] instanceof Array){

          obj[i]=[];

          break;
        }

        if(obj[i] instanceof Object){

          obj[i]={};

          break;
        }

        obj[i]='';


      break;

      default:


      obj[i]='';



    }

  }
}


//过滤器
//-----------------------------------------------------------------------------------------------

/**
 * 过滤分页数据
 */
Vue.filter('page', (value) => {

  if (!value) return 1;

  return Number(value);

});
